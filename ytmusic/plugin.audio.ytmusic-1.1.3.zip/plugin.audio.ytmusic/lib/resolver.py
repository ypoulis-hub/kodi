"""Stream URL resolver using yt-dlp (direct binary or via system Python)."""

import subprocess
import json
import os
import platform
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))

# Resolution method: 'ytdlp_cli', 'python', 'embedded', or 'innertube'
_resolve_method = None
_resolve_path = None


def log(msg):
    xbmc.log('[YTMusic] resolver: {}'.format(msg), xbmc.LOGINFO)


def _is_android():
    """Detect if running on Android."""
    return (os.path.isdir('/data/data') or
            os.environ.get('ANDROID_ROOT') or
            os.environ.get('ANDROID_DATA') or
            'android' in platform.platform().lower())


def _get_ytdlp_download_url():
    """Return the correct yt-dlp download URL and filename for the current platform."""
    is_windows = os.name == 'nt'
    machine = platform.machine().lower()

    if is_windows:
        return 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe', 'yt-dlp.exe'

    # Linux / Android - pick binary by architecture
    if machine in ('aarch64', 'arm64'):
        url = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_aarch64'
    elif machine.startswith('arm') or machine == 'armv7l':
        url = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_linux_armv7l'
    else:
        # x86_64 or fallback
        url = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp'

    return url, 'yt-dlp'


def _get_install_dir():
    """Return the best install directory for yt-dlp on the current platform."""
    if os.name == 'nt':
        return os.path.join(PROFILE, 'bin')

    if _is_android():
        # Android: use addon profile (app-private, executable)
        return os.path.join(PROFILE, 'bin')

    if os.path.isdir('/storage'):
        return '/storage/bin'  # LibreELEC

    return os.path.expanduser('~/.local/bin')


# ── yt-dlp CLI detection ──

def _find_ytdlp_cli():
    """Find a standalone yt-dlp binary on the system.

    Search order:
    1. User-configured custom path (if it points to yt-dlp, not python)
    2. Common install locations per platform
    3. PATH-based lookup
    """
    custom_path = ADDON.getSetting('python_path') or ''
    if custom_path and os.path.isfile(custom_path):
        basename = os.path.basename(custom_path).lower().replace('.exe', '')
        if basename in ('yt-dlp', 'yt_dlp'):
            if _test_ytdlp_cli(custom_path):
                return custom_path

    candidates = ['yt-dlp']
    is_windows = os.name == 'nt'

    # Check addon profile directory first (auto-install location)
    profile_exe = os.path.join(PROFILE, 'bin', 'yt-dlp.exe' if is_windows else 'yt-dlp')
    if os.path.isfile(profile_exe):
        candidates.insert(0, profile_exe)

    if is_windows:
        candidates.append('yt-dlp.exe')
    else:
        for path in ['/storage/bin/yt-dlp',  # LibreELEC
                     '/usr/local/bin/yt-dlp', '/usr/bin/yt-dlp',
                     os.path.expanduser('~/.local/bin/yt-dlp')]:
            if os.path.isfile(path):
                candidates.insert(0, path)

    for candidate in candidates:
        if _test_ytdlp_cli(candidate):
            return candidate

    return None


def _test_ytdlp_cli(candidate):
    """Test if a yt-dlp binary is functional."""
    try:
        result = subprocess.run(
            [candidate, '--version'],
            capture_output=True, text=True, timeout=10,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        if result.returncode == 0 and result.stdout.strip():
            log('Found yt-dlp CLI: {} (v{})'.format(candidate, result.stdout.strip()))
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return False


# ── Python + yt-dlp detection ──

def _find_system_python():
    """Find system Python 3 with yt-dlp installed (not Kodi's bundled one).

    Search order:
    1. User-configured custom path (from addon settings)
    2. Platform-specific common install locations
    3. Generic PATH-based candidates (python3, python, py)
    """
    custom_path = ADDON.getSetting('python_path') or ''
    if custom_path and os.path.isfile(custom_path):
        if _test_python(custom_path):
            return custom_path
        log('Custom python_path set but yt-dlp not found: {}'.format(custom_path))

    candidates = ['python3', 'python']
    is_windows = os.name == 'nt'

    if is_windows:
        candidates.append('py')
        local_appdata = os.environ.get('LOCALAPPDATA', '')
        if local_appdata:
            python_base = os.path.join(local_appdata, 'Programs', 'Python')
            if os.path.isdir(python_base):
                for sub in os.listdir(python_base):
                    exe = os.path.join(python_base, sub, 'python.exe')
                    if os.path.isfile(exe):
                        candidates.insert(0, exe)
            # Also check pythoncore (Windows Store / winget)
            for entry in os.listdir(local_appdata):
                if entry.lower().startswith('python'):
                    sub = os.path.join(local_appdata, entry)
                    if os.path.isdir(sub):
                        for item in os.listdir(sub):
                            exe = os.path.join(sub, item, 'python.exe')
                            if os.path.isfile(exe):
                                candidates.insert(0, exe)
    else:
        for path in ['/usr/bin/python3', '/usr/local/bin/python3',
                     os.path.expanduser('~/.local/bin/python3')]:
            if os.path.isfile(path):
                candidates.insert(0, path)

    for candidate in candidates:
        if _test_python(candidate):
            return candidate

    return None


def _test_python(candidate):
    """Test if a Python executable has yt-dlp available."""
    try:
        result = subprocess.run(
            [candidate, '-c', 'import yt_dlp; print("ok")'],
            capture_output=True, text=True, timeout=10,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
        if result.returncode == 0 and 'ok' in result.stdout:
            log('Found system Python with yt-dlp: {}'.format(candidate))
            return True
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        pass
    return False


# ── Embedded yt-dlp (Android) ──

YTDLP_MODULE_DIR = os.path.join(PROFILE, 'yt-dlp-module')


def _find_embedded_ytdlp():
    """Check if yt-dlp is available as a Python module (installed in addon profile)."""
    if os.path.isdir(YTDLP_MODULE_DIR):
        import sys
        if YTDLP_MODULE_DIR not in sys.path:
            sys.path.insert(0, YTDLP_MODULE_DIR)
        try:
            import yt_dlp
            log('Found embedded yt-dlp module: v{}'.format(yt_dlp.version.__version__))
            return True
        except ImportError:
            pass
    return False


def _auto_install_ytdlp_module():
    """Download yt-dlp as a Python wheel and extract it for use within Kodi's Python."""
    dialog = xbmcgui.Dialog()

    ok = dialog.yesno(
        'YTMusic - yt-dlp not found',
        'yt-dlp is required to play music but was not found on this system.\n\n'
        'Would you like to download and install it automatically?\n'
        '(This will download the yt-dlp Python package)',
    )
    if not ok:
        return False

    pbar = xbmcgui.DialogProgress()
    pbar.create('YTMusic', 'Fetching yt-dlp package info...')

    try:
        import urllib.request
        import zipfile
        import io

        # Get latest wheel URL from PyPI
        pypi_url = 'https://pypi.org/pypi/yt-dlp/json'
        resp = urllib.request.urlopen(pypi_url, timeout=30)
        pypi_data = json.loads(resp.read().decode('utf-8'))

        # Find the pure Python wheel (none-any)
        wheel_url = None
        for url_info in pypi_data.get('urls', []):
            if url_info.get('filename', '').endswith('-none-any.whl'):
                wheel_url = url_info['url']
                break

        if not wheel_url:
            pbar.close()
            dialog.ok('YTMusic', 'Could not find yt-dlp wheel on PyPI.')
            return False

        pbar.update(30, 'Downloading yt-dlp package...')
        log('Downloading yt-dlp wheel: {}'.format(wheel_url))

        resp = urllib.request.urlopen(wheel_url, timeout=120)
        wheel_data = resp.read()

        pbar.update(70, 'Extracting yt-dlp package...')

        os.makedirs(YTDLP_MODULE_DIR, exist_ok=True)

        # Extract wheel (it's a zip file)
        with zipfile.ZipFile(io.BytesIO(wheel_data)) as zf:
            # Only extract the yt_dlp package directory
            for member in zf.namelist():
                if member.startswith('yt_dlp/'):
                    zf.extract(member, YTDLP_MODULE_DIR)

        pbar.update(90, 'Verifying...')

        if _find_embedded_ytdlp():
            pbar.close()
            dialog.ok('YTMusic', 'yt-dlp installed successfully!')
            return True
        else:
            pbar.close()
            dialog.ok('YTMusic', 'yt-dlp was downloaded but failed to load.')
            return False

    except Exception as e:
        pbar.close()
        log('yt-dlp module install error: {}'.format(e))
        dialog.ok('YTMusic', 'Installation failed: {}'.format(e))
        return False


# ── Resolver init ──

def _init_resolver():
    """Detect the best available method for the current platform."""
    global _resolve_method, _resolve_path

    # On Android, use direct Innertube API (fast, no dependencies)
    if _is_android():
        _resolve_method = 'innertube'
        _resolve_path = None
        log('Using Innertube API method (Android)')
        return

    # Try direct yt-dlp binary first (no Python needed)
    ytdlp = _find_ytdlp_cli()
    if ytdlp:
        _resolve_method = 'ytdlp_cli'
        _resolve_path = ytdlp
        log('Using yt-dlp CLI method: {}'.format(ytdlp))
        return

    # Fall back to Python + yt-dlp module (subprocess)
    python = _find_system_python()
    if python:
        _resolve_method = 'python'
        _resolve_path = python
        log('Using Python method: {}'.format(python))
        return

    log('No yt-dlp resolution method found')

    # Windows / Linux: offer to install native binary
    if _auto_install_ytdlp():
        ytdlp = _find_ytdlp_cli()
        if ytdlp:
            _resolve_method = 'ytdlp_cli'
            _resolve_path = ytdlp
            log('Using yt-dlp CLI after auto-install: {}'.format(ytdlp))
            return

    log('No yt-dlp resolution method available')


def _auto_install_ytdlp():
    """Offer to download yt-dlp binary (works on Windows and Linux)."""
    dialog = xbmcgui.Dialog()

    ok = dialog.yesno(
        'YTMusic - yt-dlp not found',
        'yt-dlp is required to play music but was not found on this system.\n\n'
        'Would you like to download and install it automatically?',
    )
    if not ok:
        return False

    download_url, filename = _get_ytdlp_download_url()
    install_dir = _get_install_dir()
    install_path = os.path.join(install_dir, filename)

    log('Auto-install: arch={} url={} dest={}'.format(
        platform.machine(), download_url, install_path))

    pbar = xbmcgui.DialogProgress()
    pbar.create('YTMusic', 'Downloading yt-dlp...')

    try:
        os.makedirs(install_dir, exist_ok=True)

        import urllib.request
        urllib.request.urlretrieve(download_url, install_path)

        if os.name != 'nt':
            os.chmod(install_path, 0o755)

        pbar.close()

        if _test_ytdlp_cli(install_path):
            dialog.ok('YTMusic', 'yt-dlp installed successfully!')
            return True
        else:
            dialog.ok('YTMusic',
                       'yt-dlp was downloaded but failed to run.\n'
                       'Platform: {} {}'.format(platform.system(), platform.machine()))
            return False

    except Exception as e:
        pbar.close()
        log('yt-dlp auto-install error: {}'.format(e))
        dialog.ok('YTMusic', 'Installation failed: {}'.format(e))
        return False


def _get_resolver():
    """Return (method, path) for stream resolution."""
    if _resolve_method is None:
        _init_resolver()
    return _resolve_method, _resolve_path


# ── Stream resolution ──

def get_stream_url(video_id):
    """Resolve a stream URL using the best available method."""
    method, path = _get_resolver()

    if not method:
        raise RuntimeError(
            'Cannot find yt-dlp. Install it via:\n'
            '  Linux: sudo apt install yt-dlp  or  pipx install yt-dlp\n'
            '  Windows: pip install yt-dlp\n'
            'Or set a custom path in addon settings (Advanced > Custom Python path).'
        )

    url = 'https://music.youtube.com/watch?v={}'.format(video_id)
    log('Resolving stream for video_id={} (method={})'.format(video_id, method))

    if method == 'innertube':
        return _resolve_via_innertube(video_id)
    elif method == 'ytdlp_cli':
        return _resolve_via_cli(path, url)
    elif method == 'embedded':
        return _resolve_via_embedded(url)
    else:
        return _resolve_via_python(path, url)


def _resolve_via_cli(ytdlp_path, url):
    """Resolve stream by calling yt-dlp binary directly."""
    try:
        result = subprocess.run(
            [ytdlp_path, '-f', 'bestaudio', '-j', '--no-playlist', url],
            capture_output=True, text=True, timeout=30,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError('Stream resolution timed out.')

    if result.returncode != 0:
        log('yt-dlp CLI error: {}'.format(result.stderr[:300]))
        raise RuntimeError('yt-dlp failed: {}'.format(result.stderr[:200]))

    try:
        data = json.loads(result.stdout.strip())
    except (json.JSONDecodeError, ValueError):
        log('Bad yt-dlp output: {}'.format(result.stdout[:200]))
        raise RuntimeError('yt-dlp returned invalid output.')

    stream_url = data.get('url', '')
    if not stream_url:
        raise RuntimeError('No stream URL returned by yt-dlp.')

    info = {
        'url': stream_url,
        'title': data.get('title', ''),
        'artist': data.get('artist', data.get('uploader', '')),
        'duration': data.get('duration', 0),
        'bitrate': data.get('abr', 0),
    }

    log('Resolved: {} ({} bps)'.format(stream_url[:80], info.get('bitrate', '?')))
    return stream_url, info


def _resolve_via_python(python_path, url):
    """Resolve stream by calling yt-dlp as a Python module."""
    script = (
        'import yt_dlp, json, sys; '
        'ydl_opts = {"format": "bestaudio", "quiet": True, "no_warnings": True, "noplaylist": True}; '
        'ydl = yt_dlp.YoutubeDL(ydl_opts); '
        'info = ydl.extract_info(sys.argv[1], download=False); '
        'print(json.dumps({"url": info.get("url",""), "title": info.get("title",""), '
        '"artist": info.get("artist", info.get("uploader","")), '
        '"duration": info.get("duration",0), '
        '"bitrate": info.get("abr",0)}))'
    )

    try:
        result = subprocess.run(
            [python_path, '-c', script, url],
            capture_output=True, text=True, timeout=30,
            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError('Stream resolution timed out.')

    if result.returncode != 0:
        log('yt-dlp error: {}'.format(result.stderr[:300]))
        raise RuntimeError('yt-dlp failed: {}'.format(result.stderr[:200]))

    try:
        info = json.loads(result.stdout.strip())
    except (json.JSONDecodeError, ValueError):
        log('Bad yt-dlp output: {}'.format(result.stdout[:200]))
        raise RuntimeError('yt-dlp returned invalid output.')

    stream_url = info.get('url', '')
    if not stream_url:
        raise RuntimeError('No stream URL returned by yt-dlp.')

    log('Resolved: {} ({} bps)'.format(stream_url[:80], info.get('bitrate', '?')))
    return stream_url, info


def _resolve_via_embedded(url):
    """Resolve stream using yt-dlp imported directly into Kodi's Python (Android)."""
    import sys
    import traceback

    if YTDLP_MODULE_DIR not in sys.path:
        sys.path.insert(0, YTDLP_MODULE_DIR)

    import yt_dlp

    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'noplaylist': True,
        'skip_download': True,
        # Compatibility with Kodi's stripped-down Python
        'nocheckcertificate': True,
        'cachedir': False,
        'no_color': True,
        'geo_bypass': True,
        'socket_timeout': 30,
        'extractor_args': {'youtube': {'player_client': ['web']}},
    }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            data = ydl.extract_info(url, download=False)
    except Exception as e:
        tb = traceback.format_exc()
        log('Embedded yt-dlp error: {}'.format(tb))
        raise RuntimeError('yt-dlp failed: {}'.format(str(e)[:200]))

    if not data:
        raise RuntimeError('yt-dlp returned no data.')

    # Manually pick the best audio stream from available formats
    stream_url = ''
    bitrate = 0
    formats = data.get('formats', [])
    if formats:
        # Prefer audio-only formats
        audio_fmts = [f for f in formats if f.get('acodec', 'none') != 'none'
                      and f.get('vcodec') in ('none', None)]
        if not audio_fmts:
            # Fall back to any format with audio
            audio_fmts = [f for f in formats if f.get('acodec', 'none') != 'none']
        if not audio_fmts:
            # Last resort: any format with a URL
            audio_fmts = [f for f in formats if f.get('url')]

        if audio_fmts:
            best = max(audio_fmts, key=lambda f: f.get('abr', 0) or f.get('tbr', 0) or 0)
            stream_url = best.get('url', '')
            bitrate = best.get('abr', 0) or best.get('tbr', 0) or 0

    # Fall back to direct URL if available
    if not stream_url:
        stream_url = data.get('url', '')

    if not stream_url:
        log('No stream URL found. Formats: {}'.format(
            [(f.get('format_id'), f.get('acodec'), f.get('vcodec'), f.get('abr'))
             for f in formats[:10]]))
        raise RuntimeError('No stream URL returned by yt-dlp.')

    info = {
        'url': stream_url,
        'title': data.get('title', ''),
        'artist': data.get('artist', data.get('uploader', '')),
        'duration': data.get('duration', 0),
        'bitrate': bitrate,
    }

    log('Resolved: {} ({} bps)'.format(stream_url[:80], info.get('bitrate', '?')))
    return stream_url, info


def _resolve_via_innertube(video_id):
    """Resolve stream using direct Innertube API call (Android — no yt-dlp needed).

    Uses the IOS_MUSIC client which returns direct URLs without signatureCipher.
    WEB_REMIX returns signatureCipher URLs that require JS player deciphering.
    """
    import json
    import urllib.request
    import urllib.error
    from lib.auth import get_auth_header, get_cookie_header

    body = json.dumps({
        'context': {
            'client': {
                'clientName': 'IOS_MUSIC',
                'clientVersion': '7.27.0',
                'deviceMake': 'Apple',
                'deviceModel': 'iPhone16,2',
                'osName': 'iPhone',
                'osVersion': '18.2.1.22C161',
                'gl': 'US',
                'hl': 'en',
            },
            'user': {'lockedSafetyMode': False},
        },
        'videoId': video_id,
        'playbackContext': {
            'contentPlaybackContext': {
                'signatureTimestamp': 20073,
            }
        },
        'racyCheckOk': True,
        'contentCheckOk': True,
    }).encode('utf-8')

    api_url = ('https://music.youtube.com/youtubei/v1/player'
               '?key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30&prettyPrint=false')

    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'com.google.ios.youtubemusic/7.27.0 (iPhone16,2; U; CPU iOS 18_2_1 like Mac OS X;)',
    }

    # Add cookie-based auth
    cookie_header = get_cookie_header()
    if cookie_header:
        headers['Cookie'] = cookie_header
    auth_header = get_auth_header()
    if auth_header:
        headers['Authorization'] = auth_header

    log('Innertube IOS_MUSIC player request for video_id={}'.format(video_id))

    req = urllib.request.Request(api_url, data=body, method='POST')
    for k, v in headers.items():
        req.add_header(k, v)

    try:
        resp = urllib.request.urlopen(req, timeout=15)
        data = json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        err_body = e.read().decode('utf-8', errors='replace')[:500]
        log('Innertube HTTP {}: {}'.format(e.code, err_body))
        raise RuntimeError('Innertube API error {}'.format(e.code))
    except Exception as e:
        log('Innertube request failed: {}'.format(e))
        raise RuntimeError('Innertube API request failed: {}'.format(e))

    # Check playability
    status = data.get('playabilityStatus', {})
    if status.get('status') != 'OK':
        reason = status.get('reason', status.get('status', 'unknown'))
        log('Innertube playability error: {}'.format(reason))
        raise RuntimeError('Video not playable: {}'.format(reason))

    # Extract best audio from adaptiveFormats
    streaming = data.get('streamingData', {})
    formats = streaming.get('adaptiveFormats', [])

    # Filter to audio-only formats with direct URLs (no signatureCipher)
    audio_fmts = [f for f in formats
                  if f.get('mimeType', '').startswith('audio/') and f.get('url')]
    if not audio_fmts:
        # Try any format with a direct URL
        audio_fmts = [f for f in formats if f.get('url')]
    if not audio_fmts:
        # Log what we got for debugging
        cipher_count = sum(1 for f in formats if f.get('signatureCipher'))
        url_count = sum(1 for f in formats if f.get('url'))
        log('No direct URLs. formats={}, withUrl={}, withCipher={}'.format(
            len(formats), url_count, cipher_count))
        raise RuntimeError('No direct stream URLs (all require signature deciphering).')

    # Prefer highest bitrate audio
    best = max(audio_fmts, key=lambda f: f.get('bitrate', 0))
    stream_url = best['url']
    bitrate = best.get('bitrate', 0)
    mime = best.get('mimeType', '')

    info = {
        'url': stream_url,
        'title': data.get('videoDetails', {}).get('title', ''),
        'artist': data.get('videoDetails', {}).get('author', ''),
        'duration': int(data.get('videoDetails', {}).get('lengthSeconds', 0)),
        'bitrate': bitrate,
    }

    log('Innertube resolved: {} ({} bps, {})'.format(
        stream_url[:80], bitrate, mime))
    return stream_url, info
